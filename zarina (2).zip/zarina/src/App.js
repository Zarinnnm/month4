import React, { useState } from 'react';
import './App.css';

const App = () => {
  const [inputValue, setInputValue] = useState('');
  const [names, setNames] = useState([]);

  const handleAdd = () => {
    if (inputValue.trim() !== '') {
      setNames([...names, inputValue]);
      setInputValue('');
    }
  };

  const handleChange = (index) => {
    if (inputValue.trim() !== '') {
      const updatedNames = names.map((name, i) => (i === index ? inputValue : name));
      setNames(updatedNames);
      setInputValue('');
    }
  };

  return (
      <div className="container">
        <h1>Список имён</h1>
        <div className="input-group">
          <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Введите имя"
              className="input"
          />
          <button
              onClick={handleAdd}
              disabled={inputValue.trim() === ''}
              className="button"
          >
            Добавить
          </button>
        </div>
        <div className="list-container">
          {names.length === 0 ? (
              <p>Список пуст</p>
          ) : (
              <ul className="list">
                {names.map((name, index) => (
                    <li key={index} className="list-item">
                      <span className="name">{name}</span>
                      <button
                          onClick={() => handleChange(index)}
                          disabled={inputValue.trim() === ''}
                          className="button"
                      >
                        Поменять
                      </button>
                    </li>
                ))}
              </ul>
          )}
        </div>
      </div>
  );
};

export default App;